package com.example.assignment1;

//https://stackoverflow.com/questions/47182944/how-pass-data-from-recyclerview-to-activity/47183251
public interface UpdateWordObject {
    void UpdateWordObjectMethod(WordObject wordObject, int index);
}

